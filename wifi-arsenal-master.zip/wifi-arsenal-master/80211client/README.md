说明:使用libpcap编写的非官方校园网802.1x客户端.包括一个libpcap构造发送接收TCP/UDP数据包例子供参考.

参考了https://github.com/liuqun/openwrt-clients/tree/master/scut
