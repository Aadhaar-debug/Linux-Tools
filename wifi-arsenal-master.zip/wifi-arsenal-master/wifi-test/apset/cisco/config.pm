package config;

$ap = "192.168.50.9";
$ssid_2g="wifi-test-cisco-2.4g";
$ssid_5g="wifi-test-cisco-5g";
$EAP_Server="192.168.50.74";
$EAP_Auth_Port="1812";
#$EAP_Acct_Port="1813";

# In general, you don't need change these values
$Shared_Secret="sharedsecret";
$channel_2g=11;
$channel_5g=149;
$KEYVALUE1="1111000000";
$KEYVALUE2="2222000000";
$KEYVALUE3="11112222333344445555666611";
$KEYVALUE4="12345678901234567890123456";

$AP_Login="Cisco";
$AP_Password="Cisco";
$AP_Enable_Password="Cisco";
$psk_key="sharedsecret";

